import os
import datetime
#
# print(os.getcwd())
#
#  function to clear the screen
def clear_screen():
    os.system('cls' if os.name=='nt' else 'clear')

# load candidates file
def load_candidates():
    #why wont this work
    #trying making candidates a global?
    global candidates
    with open("candidates.txt", "r") as f: #can't get candidates.txt to load !!! #had to change directorys in cwd
        candidates = [line.strip() for line in f]

def log_vote(candidate):
    with open("votes.log", "a") as f:
        now = datetime.datetime.now()
        f.write(f"{candidate} {now}\n")
        

# count votes
def tally_votes():
    global candidates
    votes = {}
    with open("votes.log", "r") as f:
        for line in f:
            elements = line.strip().split(" ")
            if len(elements) != 4:
                print(f"Ignoring invalid line: {line.strip()}")
                continue
            date, time, first_name, last_name = elements
            candidate = f"{first_name} {last_name}"
            if candidate in candidates:
                votes[candidate] = votes.get(candidate, 0) + 1
    print(votes) # add a print statement to check the votes dictionary
    for candidate in candidates:
        print(f"{candidate}: {votes.get(candidate, 0)}")
    input("Press Enter to Continue:")



# create method for voting
def vote():
    global candidates
    clear_screen()
    print("Please select a candidate:")
    #gives candidates numbers
    for i, candidate in enumerate(candidates):
        print(f"{i+1}. {candidate}")
    selection = input()
    #deal with exceptions
    try:
        selection = int(selection)
        if selection < 1 or selection > len(candidates):
            raise ValueError
    except ValueError:
        print("Invalid selection")
        return
    candidate = candidates[selection-1]
    #clear screen
    clear_screen()
   
   #confirm vote
    print(f"You have selected {candidate}.")
    input("Press enter to confirm your selection.")
    log_vote(candidate)
    clear_screen()
    print("Your vote has been recorded.")


#clear candidates and votes for new election
def reset():
    clear_screen()
    confirmation = input("Are you sure you want to erase all candidates and votes? (y/n): ")
    #get confirmation
    if confirmation.lower() == "y":
        with open("candidates.txt", "w") as f:
            f.write("")
        with open("votes.log", "w") as f:
            f.write("")
        print("Candidates and votes erased.")
        input("Press enter to continue.")
    else:
        print("Operation cancelled.")
        input("Press enter to continue.")

#add new candidate for new election
def add_candidate():
    global candidates
    candidate = input("Enter candidate name: ")
    if candidate in candidates:
        print(f"{candidate} is already a candidate.")
    else:
        candidates.append(candidate)
        print(f"{candidate} has been added as a candidate.")

#remove individual candidate
def remove_candidate():
    global candidates
    candidate = input("Enter candidate name: ")
    if candidate in candidates:
        candidates.remove(candidate)
        print(f"{candidate} has been removed as a candidate.")
    else:
        print(f"{candidate} is not a candidate.")

#too many options
#def clear_candidates():
 #   with open("candidates.txt", "w") as file:
   #     file.truncate(0)

#combine with reset option

#def clear_vote():
    #with open("votes.log", "w") as file:
     #   file.truncate(0)

#create admin option
def admin():
    clear_screen()
    password = input("Enter password to access admin: ")
    if password == "Elector":
        while True:
            clear_screen()
            print("Please make a selection:")
            print("1. Add candidate")
            print("2. Remove candidate")
            print("3. Audit Votes")
            print("4. Reset")
            
            print("5. Back")
            selection = input()
            
            try:
                selection = int(selection)
                if selection < 1 or selection > 5:
                    raise ValueError
            except ValueError:
                print("Invalid selection")
                input("Press enter to continue.")
                continue

            if selection == 1:
                add_candidate()
            elif selection == 2:
                remove_candidate()
            elif selection == 3:
                with open("votes.log", "r") as f:
                    for line in f:
                        print(line) #prints votes so info can be audited
                    input('Press Enter to Continue')
            elif selection == 4:
                reset()
            elif selection == 5:
                clear_screen()
                return
            #elif selection == 6:
                #clear_vote()
    else:
        print("Incorrect password")
        input("Press enter to continue.")



# main man
def main():
    #if not os.path.exists("votes.txt"):
     #   with open("votes.txt", "w") as f:
            #pass
    global candidates
    load_candidates()
    while True:
        clear_screen()
        print("Please make a selection:")
        print("1. Vote")
        print("2. Tally votes")
        print("3. Shutdown")
        print("4. Admin")
        
        selection = input()
        #test against floats
        try:            #deal with exceptions
            selection = int(selection)
            if selection < 1 or selection > 4:
                raise ValueError
        except ValueError:
            print("Invalid selection")
            input("Press enter to continue.")
            continue

        if selection == 1:
            
            vote()
            
        elif selection == 2:
            clear_screen()
            tally_votes()
           

            #shut down call
        elif selection == 3:
            clear_screen()
            print("Shutting down...")
            return
        
        #access admin screen
        elif selection == 4:
            admin()

print("Current Candidates:")
with open("candidates.txt", "r") as f:
    candidates = [line.strip() for line in f]
    print(candidates)

if __name__ == "__main__":
    main()

#cwd = os.getcwd()  
#files = os.listdir(cwd)  

#for file in files:

    #print(file)